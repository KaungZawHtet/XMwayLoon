// 2019-04-11 created by Tsung-Wei Huang
//   - modifed from boost/predef/detail/comp_detected.h

#pragma once

#ifndef TF_PREDEF_DETAIL_COMP_DETECTED
#  define TF_PREDEF_DETAIL_COMP_DETECTED 1
#endif
